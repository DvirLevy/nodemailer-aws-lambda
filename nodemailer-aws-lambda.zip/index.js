const nodemailer = require('nodemailer') 
exports.handler = async (event) => {
    console.log(event)
  
    let data = event
    try{
        let transporter = nodemailer.createTransport({
            service : "gmail",
            auth: {
                user: process.env.EMAIL_ADDRESS, 
                pass: process.env.EMAIL_APP_PASS, 
            },
        });

        const option = await transporter.sendMail({
            from: data.from,
            to: data.to, 
            subject: data.subject,
            text: `<p>From: ${data.fullName}</p></br><p>message content:</p></br><p>${data.message}</p>`, 
        });

        return transporter.sendMail(option, (err,info) =>{
            if(err)
                return err
            else
                return info
        })
    }
    catch(error){
        return error.message 
    }
}